// ✅ COPY-PASTE FINAL COMPLETO
// src/controllers/pos.controller.js

const { literal } = require("sequelize");
const {
  sequelize,
  Sale,
  SaleItem,
  Payment,
  Product,
  StockBalance,
  StockMovement,
  StockMovementItem,
  Warehouse,
} = require("../models");
const { getCurrentOpenCashRegister } = require("../services/cashRegister.service");
const { resolveFiscalSnapshot } = require("../services/fiscalSnapshot.service");
const { maybeCreateFiscalDocument } = require("../services/fiscalDocument.service");

/* =========================
   Utils
========================= */
function toNum(v, def = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}

function toInt(v, def = 0) {
  const n = parseInt(String(v ?? ""), 10);
  return Number.isFinite(n) ? n : def;
}

function parseBool(v, def = false) {
  if (v === undefined || v === null) return def;

  const s = String(v).trim().toLowerCase();
  if (s === "") return def;

  if (["1", "true", "t", "yes", "y", "on"].includes(s)) return true;
  if (["0", "false", "f", "no", "n", "off"].includes(s)) return false;

  return def;
}

function normalizeRoles(raw) {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw.map((r) => String(r || "").toLowerCase()).filter(Boolean);
  return String(raw || "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

function normalizeBranchIds(raw) {
  if (!raw) return [];
  if (Array.isArray(raw)) return raw.map((x) => toInt(x, 0)).filter(Boolean);
  return String(raw || "")
    .split(",")
    .map((s) => toInt(s.trim(), 0))
    .filter(Boolean);
}

function isAdminReq(req) {
  const u = req?.user || {};
  const roles = normalizeRoles(u.roles);

  if (roles.includes("admin") || roles.includes("superadmin") || roles.includes("super_admin")) return true;

  const role = String(u.role || u.user_role || "").toLowerCase();
  if (role === "admin" || role === "superadmin" || role === "super_admin") return true;

  if (u.is_admin === true) return true;

  return false;
}

function rid(req) {
  return (
    req?.headers?.["x-request-id"] ||
    req?.headers?.["x-correlation-id"] ||
    `${Date.now()}-${Math.random().toString(16).slice(2)}`
  );
}

function logPos(req, level, msg, extra = {}) {
  const base = {
    rid: req._rid,
    path: req.originalUrl,
    method: req.method,
    user_id: req?.user?.id ?? null,
    user_email: req?.user?.email ?? null,
    user_branch_id: req?.user?.branch_id ?? null,
    user_role: req?.user?.role ?? req?.user?.user_role ?? null,
    user_roles: req?.user?.roles ?? null,
    user_branches: req?.user?.branches ?? null,
    ctx_branchId: req?.ctx?.branchId ?? null,
    ctx_warehouseId: req?.ctx?.warehouseId ?? null,
    q_branch_id: req?.query?.branch_id ?? req?.query?.branchId ?? null,
    q_warehouse_id: req?.query?.warehouse_id ?? req?.query?.warehouseId ?? null,
  };
  console[level](`[POS] ${msg}`, { ...base, ...extra });
}

function resolveExplicitPosContext(req) {
  const branchId =
    toInt(req?.body?.branch_id, 0) || toInt(req?.query?.branch_id, 0) || toInt(req?.query?.branchId, 0);

  const warehouseId =
    toInt(req?.body?.warehouse_id, 0) || toInt(req?.query?.warehouse_id, 0) || toInt(req?.query?.warehouseId, 0);

  return { branchId, warehouseId };
}

function resolvePosContext(req) {
  const branchId =
    toInt(req?.body?.branch_id, 0) ||
    toInt(req?.query?.branch_id, 0) ||
    toInt(req?.query?.branchId, 0) ||
    toInt(req?.ctx?.branchId, 0);

  const warehouseId =
    toInt(req?.body?.warehouse_id, 0) ||
    toInt(req?.query?.warehouse_id, 0) ||
    toInt(req?.query?.warehouseId, 0) ||
    toInt(req?.ctx?.warehouseId, 0);

  return { branchId, warehouseId };
}

async function resolveWarehouseForBranch(branchId) {
  const bid = toInt(branchId, 0);
  if (!bid) return 0;

  const w = await Warehouse.findOne({
    where: { branch_id: bid },
    order: [["id", "ASC"]],
    attributes: ["id"],
  });

  return toInt(w?.id, 0);
}

async function assertWarehouseBelongsToBranch(warehouseId, branchId) {
  const wid = toInt(warehouseId, 0);
  const bid = toInt(branchId, 0);
  if (!wid || !bid) return true;

  const w = await Warehouse.findByPk(wid, { attributes: ["id", "branch_id"] });
  if (!w) return false;
  return toInt(w.branch_id, 0) === bid;
}

function clampInstallments(v, def = 1) {
  const n = toInt(v, def);
  if (!Number.isFinite(n)) return def;
  if (n < 1) return 1;
  if (n > 12) return 12;
  return n;
}

function safeJsonParse(s) {
  try {
    const x = JSON.parse(String(s || ""));
    return x && typeof x === "object" ? x : null;
  } catch {
    return null;
  }
}

function mergePaymentNote(existingNote, metaObj) {
  const prev = safeJsonParse(existingNote) || {};
  const merged = { ...prev, ...metaObj };
  let out = "";
  try {
    out = JSON.stringify(merged);
  } catch {
    out = JSON.stringify(metaObj);
  }
  if (out.length > 800) out = out.slice(0, 800);
  return out;
}

function mapPayMethodDetailed(rawMethod, rawReference) {
  const ref = String(rawReference || "").trim().toUpperCase();
  const rawStr = String(rawMethod || "").trim();
  const m = rawStr.toUpperCase();

  if (ref === "SJCREDIT" || ref === "SJ_CREDIT" || ref === "SANJUANCREDITO") {
    return { dbMethod: "CREDIT_SJT", providerCode: "credit_sjt" };
  }

  if (
    rawStr === "credit_sjt" ||
    m === "CREDIT_SJT" ||
    m === "CREDITO_SJT" ||
    m === "CREDITO SAN JUAN" ||
    m === "CRÉDITO SAN JUAN" ||
    m === "SJCREDIT"
  ) {
    return { dbMethod: "CREDIT_SJT", providerCode: "credit_sjt" };
  }

  if (m === "MERCADOPAGO" || m === "MERCADO_PAGO" || m === "MERCADO PAGO" || m === "MP") {
    return { dbMethod: "MERCADOPAGO", providerCode: "mercadopago" };
  }

  if (m === "EFECTIVO") return { dbMethod: "CASH", providerCode: "cash" };
  if (m === "TRANSFERENCIA") return { dbMethod: "TRANSFER", providerCode: "transfer" };
  if (m === "TARJETA" || m === "CREDITO" || m === "CRÉDITO") return { dbMethod: "CARD", providerCode: "card" };
  if (m === "DEBITO" || m === "DÉBITO") return { dbMethod: "CARD", providerCode: "debit" };
  if (m === "QR") return { dbMethod: "QR", providerCode: "qr" };

  if (m === "CASH") return { dbMethod: "CASH", providerCode: "cash" };
  if (m === "TRANSFER") return { dbMethod: "TRANSFER", providerCode: "transfer" };
  if (m === "CARD") return { dbMethod: "CARD", providerCode: "card" };
  if (m === "QR") return { dbMethod: "QR", providerCode: "qr" };
  if (m === "MERCADOPAGO") return { dbMethod: "MERCADOPAGO", providerCode: "mercadopago" };
  if (m === "CREDIT_SJT") return { dbMethod: "CREDIT_SJT", providerCode: "credit_sjt" };
  if (m === "OTHER") return { dbMethod: "OTHER", providerCode: "other" };

  return { dbMethod: "OTHER", providerCode: rawStr ? rawStr : "other" };
}

function mapPayMethod(raw) {
  return mapPayMethodDetailed(raw, null).dbMethod;
}

/* =========================
   GET /pos/context
========================= */
async function getContext(req, res) {
  req._rid = req._rid || rid(req);

  try {
    const admin = isAdminReq(req);
    const userBranchId = toInt(req?.user?.branch_id, 0);

    const explicit = resolveExplicitPosContext(req);
    const fallback = resolvePosContext(req);

    const resolvedBranchId = admin
      ? toInt(explicit.branchId, 0) || userBranchId || toInt(fallback.branchId, 0) || 0
      : userBranchId;

    let resolvedWarehouseId = admin ? toInt(explicit.warehouseId, 0) : toInt(fallback.warehouseId, 0);

    if (!admin && !resolvedWarehouseId && resolvedBranchId) {
      resolvedWarehouseId = await resolveWarehouseForBranch(resolvedBranchId);
    }
    if (admin && !resolvedWarehouseId && resolvedBranchId) {
      resolvedWarehouseId = await resolveWarehouseForBranch(resolvedBranchId);
    }

    logPos(req, "info", "getContext resolved", {
      admin,
      resolvedBranchId,
      resolvedWarehouseId,
      explicit,
      fallback,
    });

    let warehouseObj = null;
    if (resolvedWarehouseId) {
      const w = await Warehouse.findByPk(resolvedWarehouseId, {
        attributes: ["id", "branch_id", "name"],
      });
      if (w) warehouseObj = w.toJSON();
    }

    return res.json({
      ok: true,
      data: {
        user: req.user
          ? {
              id: req.user.id,
              email: req.user.email,
              username: req.user.username,
              branch_id: req.user.branch_id,
              roles: req.user.roles,
              role: req.user.role || req.user.user_role || null,
              is_admin: req.user.is_admin || false,
              branches: req.user.branches || null,
            }
          : null,
        branch: resolvedBranchId ? { id: resolvedBranchId } : null,
        warehouse: warehouseObj || (resolvedWarehouseId ? { id: resolvedWarehouseId } : null),
        branchId: resolvedBranchId || null,
        warehouseId: resolvedWarehouseId || null,
      },
    });
  } catch (e) {
    logPos(req, "error", "getContext error", { err: e.message });
    return res.status(500).json({ ok: false, code: "POS_CONTEXT_ERROR", message: e.message });
  }
}

/* =========================
   GET /pos/products
========================= */
async function listProductsForPos(req, res) {
  req._rid = req._rid || rid(req);

  try {
    const admin = isAdminReq(req);
    const explicit = resolveExplicitPosContext(req);
    const requestedBranchId = toInt(explicit.branchId, 0) || 0;
    const requestedWarehouseId = toInt(explicit.warehouseId, 0) || 0;
    const allowedBranchIds = normalizeBranchIds(req?.user?.branches);

    if (!admin && !allowedBranchIds.length) {
      return res.status(403).json({
        ok: false,
        code: "NO_BRANCH_SCOPE",
        message: "El usuario no tiene branches asignadas para ver stock.",
      });
    }

    const q = String(req.query.q || "").trim();
    const like = `%${q}%`;

    const categoryId = toInt(req.query.category_id || req.query.categoryId, 0) || null;
    const subcategoryId = toInt(req.query.subcategory_id || req.query.subcategoryId, 0) || null;

    const limit = Math.min(Math.max(parseInt(req.query.limit || "48", 10), 1), 5000);
    const page = Math.max(parseInt(req.query.page || "1", 10), 1);
    const offset = (page - 1) * limit;

    const inStock = parseBool(req.query.in_stock, true);
    const sellable = parseBool(req.query.sellable, true);

    const priceExpr = `
      COALESCE(
        NULLIF(p.price_discount,0),
        NULLIF(p.price_list,0),
        NULLIF(p.price_reseller,0),
        p.price,
        0
      )
    `;

    const whereSellable = sellable ? `AND (${priceExpr}) > 0` : "";
    const whereQ = q
      ? `AND (
          p.name LIKE :like OR p.sku LIKE :like OR p.barcode LIKE :like OR p.code LIKE :like
          OR p.brand LIKE :like OR p.model LIKE :like
        )`
      : "";
    const whereCategory = categoryId ? `AND p.category_id = :categoryId` : "";
    const whereSubcategory = subcategoryId ? `AND p.subcategory_id = :subcategoryId` : "";

    if (requestedWarehouseId) {
      const whereStock = inStock ? `AND COALESCE(sb.qty, 0) > 0` : "";

      const [rows] = await sequelize.query(
        `
        SELECT
          p.id, p.branch_id, p.code, p.sku, p.barcode, p.name, p.brand, p.model,
          p.category_id, p.subcategory_id, p.is_new, p.is_promo, p.is_active,
          p.price, p.price_list, p.price_discount, p.price_reseller,
          (${priceExpr}) AS effective_price,
          COALESCE(sb.qty, 0) AS qty
        FROM products p
        LEFT JOIN stock_balances sb
          ON sb.product_id = p.id AND sb.warehouse_id = :warehouseId
        WHERE p.is_active = 1
        ${whereQ}
        ${whereCategory}
        ${whereSubcategory}
        ${whereStock}
        ${whereSellable}
        ORDER BY p.name ASC
        LIMIT :limit OFFSET :offset
        `,
        {
          replacements: {
            warehouseId: requestedWarehouseId,
            like,
            limit,
            offset,
            categoryId: categoryId || undefined,
            subcategoryId: subcategoryId || undefined,
          },
        }
      );

      const [[countRow]] = await sequelize.query(
        `
        SELECT COUNT(*) AS total
        FROM products p
        LEFT JOIN stock_balances sb
          ON sb.product_id = p.id AND sb.warehouse_id = :warehouseId
        WHERE p.is_active = 1
        ${whereQ}
        ${whereCategory}
        ${whereSubcategory}
        ${inStock ? `AND COALESCE(sb.qty,0) > 0` : ""}
        ${whereSellable}
        `,
        {
          replacements: {
            warehouseId: requestedWarehouseId,
            like,
            categoryId: categoryId || undefined,
            subcategoryId: subcategoryId || undefined,
          },
        }
      );

      return res.json({
        ok: true,
        data: rows,
        meta: {
          scope: "WAREHOUSE",
          page,
          limit,
          total: Number(countRow?.total || 0),
          warehouse_id: requestedWarehouseId,
        },
      });
    }

    if (admin) {
      const scopeBranchId = requestedBranchId || 0;

      const qtyExpr = scopeBranchId
        ? `COALESCE(SUM(CASE WHEN w.branch_id = :branchId THEN sb.qty ELSE 0 END), 0)`
        : `COALESCE(SUM(sb.qty), 0)`;

      const havingStock = inStock ? `HAVING ${qtyExpr} > 0` : "";

      const [rows] = await sequelize.query(
        `
        SELECT
          p.id, p.branch_id, p.code, p.sku, p.barcode, p.name, p.brand, p.model,
          p.category_id, p.subcategory_id, p.is_new, p.is_promo, p.is_active,
          p.price, p.price_list, p.price_discount, p.price_reseller,
          (${priceExpr}) AS effective_price,
          ${qtyExpr} AS qty
        FROM products p
        LEFT JOIN stock_balances sb ON sb.product_id = p.id
        LEFT JOIN warehouses w ON w.id = sb.warehouse_id
        WHERE p.is_active = 1
        ${whereQ}
        ${whereCategory}
        ${whereSubcategory}
        ${whereSellable}
        GROUP BY p.id
        ${havingStock}
        ORDER BY p.name ASC
        LIMIT :limit OFFSET :offset
        `,
        {
          replacements: {
            like,
            limit,
            offset,
            branchId: scopeBranchId || undefined,
            categoryId: categoryId || undefined,
            subcategoryId: subcategoryId || undefined,
          },
        }
      );

      const [[countRow]] = await sequelize.query(
        `
        SELECT COUNT(*) AS total
        FROM (
          SELECT p.id
          FROM products p
          LEFT JOIN stock_balances sb ON sb.product_id = p.id
          LEFT JOIN warehouses w ON w.id = sb.warehouse_id
          WHERE p.is_active = 1
          ${whereQ}
          ${whereCategory}
          ${whereSubcategory}
          ${whereSellable}
          GROUP BY p.id
          ${havingStock}
        ) x
        `,
        {
          replacements: {
            like,
            branchId: scopeBranchId || undefined,
            categoryId: categoryId || undefined,
            subcategoryId: subcategoryId || undefined,
          },
        }
      );

      return res.json({
        ok: true,
        data: rows,
        meta: {
          scope: "ADMIN_ALL",
          page,
          limit,
          total: Number(countRow?.total || 0),
          branch_id: scopeBranchId || null,
        },
      });
    }

    if (requestedBranchId && !allowedBranchIds.includes(requestedBranchId)) {
      return res.status(403).json({
        ok: false,
        code: "BRANCH_NOT_ALLOWED",
        message: `No tenés permisos para operar/ver la sucursal ${requestedBranchId}.`,
      });
    }

    const scopeBranchIds = requestedBranchId ? [requestedBranchId] : allowedBranchIds;
    const qtyExpr = `COALESCE(SUM(CASE WHEN w.branch_id IN (:branchIds) THEN sb.qty ELSE 0 END), 0)`;
    const havingStock = inStock ? `HAVING ${qtyExpr} > 0` : "";

    logPos(req, "info", "listProductsForPos scope", {
      admin,
      requestedBranchId,
      requestedWarehouseId,
      allowedBranchIds,
      scopeBranchIds,
      inStock,
      sellable,
      categoryId,
      subcategoryId,
    });

    const [rows] = await sequelize.query(
      `
      SELECT
        p.id, p.branch_id, p.code, p.sku, p.barcode, p.name, p.brand, p.model,
        p.category_id, p.subcategory_id, p.is_new, p.is_promo, p.is_active,
        p.price, p.price_list, p.price_discount, p.price_reseller,
        (${priceExpr}) AS effective_price,
        ${qtyExpr} AS qty
      FROM products p
      LEFT JOIN stock_balances sb ON sb.product_id = p.id
      LEFT JOIN warehouses w ON w.id = sb.warehouse_id
      WHERE p.is_active = 1
      ${whereQ}
      ${whereCategory}
      ${whereSubcategory}
      ${whereSellable}
      GROUP BY p.id
      ${havingStock}
      ORDER BY p.name ASC
      LIMIT :limit OFFSET :offset
      `,
      {
        replacements: {
          like,
          limit,
          offset,
          branchIds: scopeBranchIds,
          categoryId: categoryId || undefined,
          subcategoryId: subcategoryId || undefined,
        },
      }
    );

    const [[countRow]] = await sequelize.query(
      `
      SELECT COUNT(*) AS total
      FROM (
        SELECT p.id
        FROM products p
        LEFT JOIN stock_balances sb ON sb.product_id = p.id
        LEFT JOIN warehouses w ON w.id = sb.warehouse_id
        WHERE p.is_active = 1
        ${whereQ}
        ${whereCategory}
        ${whereSubcategory}
        ${whereSellable}
        GROUP BY p.id
        ${havingStock}
      ) x
      `,
      {
        replacements: {
          like,
          branchIds: scopeBranchIds,
          categoryId: categoryId || undefined,
          subcategoryId: subcategoryId || undefined,
        },
      }
    );

    return res.json({
      ok: true,
      data: rows,
      meta: {
        scope: "USER_SCOPE_ALL",
        page,
        limit,
        total: Number(countRow?.total || 0),
        branch_ids: scopeBranchIds,
      },
    });
  } catch (e) {
    logPos(req, "error", "listProductsForPos error", { err: e.message });
    return res.status(500).json({ ok: false, code: "POS_PRODUCTS_ERROR", message: e.message });
  }
}

/* =========================
   POST /pos/sales
========================= */
async function createSale(req, res) {
  req._rid = req._rid || rid(req);

  let t;
  try {
    const admin = isAdminReq(req);
    if (admin) logPos(req, "info", "createSale admin allowed");

    const body = req.body || {};
    const items = Array.isArray(body.items) ? body.items : [];
    const payments = Array.isArray(body.payments) ? body.payments : [];

    console.log("[POS][createSale][body]", JSON.stringify(body, null, 2));

    const extra = body.extra && typeof body.extra === "object" ? body.extra : {};
    const c =
      extra.customer && typeof extra.customer === "object"
        ? extra.customer
        : body.customer && typeof body.customer === "object"
          ? body.customer
          : {};

    const p0 = payments[0] && typeof payments[0] === "object" ? payments[0] : {};

    function pickFirst(...vals) {
      for (const v of vals) {
        const s = String(v ?? "").trim();
        if (s) return s;
      }
      return "";
    }

    function normalizePhone(v) {
      const s = String(v ?? "").trim();
      if (!s) return "";
      return s.replace(/[^\d+]/g, "");
    }

    const first = pickFirst(c.first_name, c.firstname, c.firstName, c.nombre);
    const last = pickFirst(c.last_name, c.lastname, c.lastName, c.apellido);
    const fullName = `${first} ${last}`.trim();

    const customer_name =
      pickFirst(
        body.customer_name,
        c.customer_name,
        c.name,
        c.full_name,
        c.fullName,
        c.razon_social,
        c.razonSocial,
        fullName,
        p0.customer_name
      ) || "Consumidor Final";

    const customer_doc =
      pickFirst(
        body.customer_doc,
        c.customer_doc,
        c.doc,
        c.dni,
        c.cuit,
        c.cuil,
        c.document,
        c.documento,
        p0.customer_doc,
        p0.doc,
        p0.dni,
        p0.cuit,
        p0.cuil
      ) || null;

    const customer_phone =
      normalizePhone(
        pickFirst(
          body.customer_phone,
          c.customer_phone,
          c.phone,
          c.tel,
          c.telefono,
          c.celular,
          c.mobile,
          c.whatsapp,
          c.wa,
          p0.customer_phone,
          p0.phone,
          p0.tel,
          p0.telefono,
          p0.whatsapp,
          p0.wa
        )
      ) || null;

    const note = body.note || null;

    console.log("[POS][createSale][customer resolved]", {
      customer_name,
      customer_doc,
      customer_phone,
    });

    if (!req.user?.id) {
      logPos(req, "warn", "createSale blocked: unauthorized");
      return res.status(401).json({ ok: false, code: "UNAUTHORIZED", message: "No autenticado" });
    }

    const userId = toInt(req.user.id, 0);
    const userBranchId = toInt(req.user.branch_id, 0);

    const explicit = resolveExplicitPosContext(req);
    const ctx = resolvePosContext(req);

    const resolvedBranchId = admin
      ? toInt(explicit.branchId, 0) || userBranchId || toInt(ctx.branchId, 0) || 0
      : userBranchId;

    if (!resolvedBranchId) {
      logPos(req, "warn", "createSale blocked: missing branch", { admin, userBranchId, explicit, ctx });
      return res.status(400).json({
        ok: false,
        code: "BRANCH_REQUIRED",
        message: admin
          ? "Admin: falta branch_id explícito (query/body) o branch_id en el usuario."
          : "Falta branch_id (sucursal). El usuario no tiene sucursal asignada.",
      });
    }

    let resolvedWarehouseId = admin
      ? toInt(explicit.warehouseId, 0) || toInt(ctx.warehouseId, 0) || 0
      : toInt(ctx.warehouseId, 0) || 0;

    if (!admin && !resolvedWarehouseId && resolvedBranchId) {
      resolvedWarehouseId = await resolveWarehouseForBranch(resolvedBranchId);
    }
    if (admin && !resolvedWarehouseId && resolvedBranchId) {
      resolvedWarehouseId = await resolveWarehouseForBranch(resolvedBranchId);
    }

    if (!resolvedWarehouseId) {
      logPos(req, "warn", "createSale blocked: missing warehouse", { resolvedBranchId, admin, explicit, ctx });
      return res.status(400).json({
        ok: false,
        code: "WAREHOUSE_REQUIRED",
        message:
          "Falta warehouse_id (depósito). Enviá warehouse_id o asegurate de tener al menos 1 depósito creado para la sucursal.",
      });
    }

    if (admin) {
      const ok = await assertWarehouseBelongsToBranch(resolvedWarehouseId, resolvedBranchId);
      if (!ok) {
        return res.status(400).json({
          ok: false,
          code: "WAREHOUSE_BRANCH_MISMATCH",
          message: "El warehouse_id no pertenece al branch_id indicado.",
        });
      }
    }

    if (items.length === 0) {
      logPos(req, "warn", "createSale blocked: empty items");
      return res.status(400).json({ ok: false, code: "EMPTY_ITEMS", message: "Venta sin items" });
    }

    const normalizedItems = items.map((i) => ({
      product_id: toNum(i.product_id),
      quantity: toNum(i.quantity),
      unit_price: toNum(i.unit_price),
    }));

    for (const it of normalizedItems) {
      if (!it.product_id) {
        throw Object.assign(new Error("Item inválido: falta product_id"), { httpStatus: 400, code: "INVALID_ITEM" });
      }
      if (!Number.isFinite(it.quantity) || it.quantity <= 0) {
        throw Object.assign(new Error(`Item inválido: quantity=${it.quantity}`), {
          httpStatus: 400,
          code: "INVALID_ITEM",
        });
      }
      if (!Number.isFinite(it.unit_price) || it.unit_price <= 0) {
        throw Object.assign(new Error(`Item inválido: unit_price=${it.unit_price}`), {
          httpStatus: 400,
          code: "INVALID_ITEM",
        });
      }
    }

    let subtotal = 0;
    for (const it of normalizedItems) subtotal += it.quantity * it.unit_price;

    logPos(req, "info", "createSale start", {
      admin,
      resolvedBranchId,
      resolvedWarehouseId,
      items: normalizedItems.length,
      payments: payments.length,
      subtotal,
      customer_name,
      customer_phone,
      customer_doc,
    });

    t = await sequelize.transaction();

    const currentCashRegister = await getCurrentOpenCashRegister({
      branch_id: resolvedBranchId,
      transaction: t,
    });

    const fiscalSnapshot = resolveFiscalSnapshot({
      body,
      cashRegister: currentCashRegister,
    });

    const sale = await Sale.create(
      {
        branch_id: resolvedBranchId,
        cash_register_id: currentCashRegister?.id || null,
        user_id: userId,
        status: "PAID",
        sale_number: null,

        customer_name,
        customer_phone,
        customer_doc,

        customer_email: fiscalSnapshot?.customer_email || null,
        customer_address: fiscalSnapshot?.customer_address || null,
        customer_doc_type: fiscalSnapshot?.customer_doc_type || null,
        customer_tax_condition: fiscalSnapshot?.customer_tax_condition || null,
        invoice_mode: fiscalSnapshot?.invoice_mode || null,
        invoice_type: fiscalSnapshot?.invoice_type || null,
        fiscal_status: fiscalSnapshot?.invoice_mode && fiscalSnapshot.invoice_mode !== "NO_FISCAL" ? "PENDING" : "NOT_REQUESTED",

        subtotal,
        discount_total: 0,
        tax_total: 0,
        total: subtotal,
        paid_total: 0,
        change_total: 0,
        note,
        sold_at: new Date(),
      },
      { transaction: t }
    );

    const movement = await StockMovement.create(
      {
        type: "out",
        warehouse_id: resolvedWarehouseId,
        ref_type: "sale",
        ref_id: String(sale.id),
        note: `Venta POS #${sale.id}`,
        created_by: userId,
      },
      { transaction: t }
    );

    for (const it of normalizedItems) {
      const p = await Product.findByPk(it.product_id, { transaction: t });
      if (!p) {
        throw Object.assign(new Error(`Producto no existe: id=${it.product_id}`), {
          httpStatus: 400,
          code: "PRODUCT_NOT_FOUND",
        });
      }

      const sb = await StockBalance.findOne({
        where: { warehouse_id: resolvedWarehouseId, product_id: it.product_id },
        transaction: t,
        lock: t.LOCK.UPDATE,
      });

      if (!sb) {
        throw Object.assign(
          new Error(`No existe stock_balance para producto ${p.sku || p.id} en depósito ${resolvedWarehouseId}`),
          { httpStatus: 409, code: "STOCK_BALANCE_MISSING" }
        );
      }

      if (Number(sb.qty) < it.quantity) {
        throw Object.assign(
          new Error(`Stock insuficiente (depósito ${resolvedWarehouseId}) para producto ${p.sku || p.id}`),
          { httpStatus: 409, code: "STOCK_INSUFFICIENT" }
        );
      }

      await sb.update({ qty: literal(`qty - ${it.quantity}`) }, { transaction: t });

      const lineTotal = it.quantity * it.unit_price;

      await SaleItem.create(
        {
          sale_id: sale.id,
          product_id: it.product_id,
          warehouse_id: resolvedWarehouseId,
          quantity: it.quantity,
          unit_price: it.unit_price,
          discount_amount: 0,
          tax_amount: 0,
          line_total: lineTotal,
          product_name_snapshot: p.name,
          product_sku_snapshot: p.sku,
          product_barcode_snapshot: p.barcode,
        },
        { transaction: t }
      );

      await StockMovementItem.create(
        {
          movement_id: movement.id,
          product_id: it.product_id,
          qty: it.quantity,
          unit_cost: p.cost || null,
        },
        { transaction: t }
      );
    }

    let totalPaid = 0;

    for (const pay of payments) {
      const amount = toNum(pay.amount);

      const referenceIncoming =
        pay.reference ||
        pay.proof ||
        body.reference ||
        body.proof ||
        body.payment_reference ||
        null;

      const { dbMethod, providerCode } = mapPayMethodDetailed(pay.method, referenceIncoming);

      if (!Number.isFinite(amount) || amount <= 0) {
        throw Object.assign(new Error(`Pago inválido: amount=${pay.amount}`), {
          httpStatus: 400,
          code: "INVALID_PAYMENT",
        });
      }

      if (!["CASH", "TRANSFER", "CARD", "QR", "MERCADOPAGO", "CREDIT_SJT", "OTHER"].includes(dbMethod)) {
        throw Object.assign(new Error(`Pago inválido: method=${dbMethod}`), {
          httpStatus: 400,
          code: "INVALID_PAYMENT_METHOD",
        });
      }

      const cardKind = String(pay.card_kind || pay.cardKind || pay.card_type || pay.cardType || "")
        .trim()
        .toUpperCase();

      const isDebit =
        providerCode === "debit" ||
        cardKind === "DEBIT" ||
        cardKind === "DEBITO" ||
        cardKind === "DÉBITO" ||
        pay.is_debit === true ||
        pay.isDebit === true;

      let installments = 1;

      if (dbMethod === "CREDIT_SJT" || providerCode === "credit_sjt") {
        installments = clampInstallments(pay.installments ?? pay.cuotas ?? pay.installment_count ?? 1, 1);
      } else if (dbMethod === "CARD") {
        if (!isDebit) installments = clampInstallments(pay.installments ?? pay.cuotas ?? pay.installment_count ?? 1, 1);
        else installments = 1;
      } else {
        installments = 1;
      }

      const priceBasis = String(pay.price_basis || pay.priceBasis || "").trim().toUpperCase() || null;
      const effectiveBasis =
        (dbMethod === "CARD" && installments > 1 && !isDebit) || dbMethod === "CREDIT_SJT"
          ? "LIST"
          : priceBasis || null;

      const listTotal = toNum(pay.total_list ?? pay.totalList ?? pay.list_total ?? 0, 0) || null;
      const perInstallmentList =
        toNum(pay.per_installment_list ?? pay.perInstallmentList ?? pay.cuota_valor ?? 0, 0) || null;

      const meta =
        installments > 1 || providerCode
          ? {
              provider_code: providerCode || null,
              installments,
              price_basis: effectiveBasis,
              list_total: listTotal,
              per_installment_list: perInstallmentList,
              card_kind: dbMethod === "CARD" ? (isDebit ? "DEBIT" : "CREDIT") : "CREDIT",
            }
          : null;

      totalPaid += amount;

      let ref = referenceIncoming || null;
      if (!ref && dbMethod === "CREDIT_SJT") ref = "SJCREDIT";
      if (!ref && dbMethod === "MERCADOPAGO") ref = "MERCADOPAGO";

      let notePay = pay.note || null;
      if (meta) notePay = mergePaymentNote(notePay, meta);

      await Payment.create(
        {
          sale_id: sale.id,
          method: dbMethod,
          amount,
          installments,
          reference: ref,
          note: notePay,
          paid_at: new Date(),
        },
        { transaction: t }
      );
    }

    if (payments.length === 0) totalPaid = subtotal;

    sale.paid_total = totalPaid;
    sale.change_total = totalPaid - subtotal;
    await sale.save({ transaction: t });

    const fiscalDocument = await maybeCreateFiscalDocument({
      sale,
      snapshot: fiscalSnapshot,
      transaction: t,
    });

    await t.commit();

    logPos(req, "info", "createSale done", {
      sale_id: sale.id,
      cash_register_id: sale.cash_register_id || null,
      fiscal_document_id: fiscalDocument?.id || sale.fiscal_document_id || null,
      resolvedBranchId,
      resolvedWarehouseId,
      totalPaid,
      change: sale.change_total,
    });

    return res.json({
      ok: true,
      data: {
        sale_id: sale.id,
        branch_id: sale.branch_id,
        cash_register_id: sale.cash_register_id || null,
        fiscal_document_id: fiscalDocument?.id || sale.fiscal_document_id || null,
        fiscal_status: sale.fiscal_status || (fiscalDocument ? "PENDING" : "NOT_REQUESTED"),
        user_id: sale.user_id,
        warehouse_id: resolvedWarehouseId,

        customer_name: sale.customer_name,
        customer_phone: sale.customer_phone,
        customer_doc: sale.customer_doc,

        subtotal: sale.subtotal,
        total: sale.total,
        paid_total: sale.paid_total,
        change_total: sale.change_total,
        status: sale.status,
        sold_at: sale.sold_at,
      },
    });
  } catch (e) {
    if (t) await t.rollback();

    const status = e.httpStatus || 500;
    const code = e.code || "POS_CREATE_SALE_ERROR";

    logPos(req, "error", "createSale error", { code, err: e.message });
    return res.status(status).json({ ok: false, code, message: e.message });
  }
}

/* ======================================================================
   DEVOLUCIONES + CAMBIOS
   ====================================================================== */

async function assertReturnsTablesExist() {
  const [[r1]] = await sequelize.query(`SHOW TABLES LIKE 'sale_returns'`);
  const [[r2]] = await sequelize.query(`SHOW TABLES LIKE 'sale_return_items'`);
  const [[r3]] = await sequelize.query(`SHOW TABLES LIKE 'sale_return_payments'`);
  if (!r1 || !r2 || !r3) {
    const err = new Error(
      "Faltan tablas de devoluciones (sale_returns / sale_return_items / sale_return_payments). Ejecutá el SQL primero."
    );
    err.httpStatus = 400;
    err.code = "RETURNS_TABLES_MISSING";
    throw err;
  }
}

async function assertExchangesTableExist() {
  const [[r]] = await sequelize.query(`SHOW TABLES LIKE 'sale_exchanges'`);
  if (!r) {
    const err = new Error("Falta tabla de cambios (sale_exchanges). Ejecutá el SQL primero.");
    err.httpStatus = 400;
    err.code = "EXCHANGES_TABLE_MISSING";
    throw err;
  }
}

function calcReturnTotal(items) {
  let total = 0;
  for (const it of items || []) {
    total += toNum(it.qty) * toNum(it.unit_price);
  }
  return Number(total || 0);
}

async function createSaleReturn(req, res) {
  req._rid = req._rid || rid(req);

  let t;
  try {
    await assertReturnsTablesExist();

    if (!req.user?.id) {
      return res.status(401).json({ ok: false, code: "UNAUTHORIZED", message: "No autenticado" });
    }

    const admin = isAdminReq(req);
    const userId = toInt(req.user.id, 0);
    const userBranchId = toInt(req.user.branch_id, 0);

    const body = req.body || {};
    const saleId = toInt(body.sale_id || body.id || req.params?.id, 0);
    const restock = parseBool(body.restock, true);
    const reason = body.reason ? String(body.reason).slice(0, 255) : null;
    const note = body.note ? String(body.note).slice(0, 255) : null;

    const items = Array.isArray(body.items) ? body.items : [];
    const payments = Array.isArray(body.payments) ? body.payments : [];

    if (!saleId) return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "sale_id requerido" });
    if (!items.length)
      return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "items requerido (array no vacío)" });
    if (!payments.length)
      return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "payments requerido (array no vacío)" });

    t = await sequelize.transaction();

    const sale = await Sale.findByPk(saleId, {
      include: [{ model: SaleItem }, { model: Payment }],
      transaction: t,
      lock: t.LOCK.UPDATE,
    });

    if (!sale) {
      await t.rollback();
      return res.status(404).json({ ok: false, code: "SALE_NOT_FOUND", message: "Venta no encontrada" });
    }

    if (!admin) {
      if (!userBranchId) {
        await t.rollback();
        return res
          .status(400)
          .json({ ok: false, code: "BRANCH_REQUIRED", message: "El usuario no tiene sucursal asignada" });
      }
      if (toInt(sale.branch_id, 0) !== userBranchId) {
        await t.rollback();
        return res.status(403).json({
          ok: false,
          code: "CROSS_BRANCH_SALE",
          message: "No podés operar una venta de otra sucursal",
        });
      }
    }

    const normalizedItems = items.map((it) => ({
      product_id: toInt(it.product_id, 0),
      warehouse_id: toInt(it.warehouse_id, 0),
      qty: toNum(it.qty),
      unit_price: toNum(it.unit_price),
    }));

    for (const it of normalizedItems) {
      if (!it.product_id || !it.warehouse_id) {
        const e = new Error("Item devolución inválido: product_id y warehouse_id requeridos");
        e.httpStatus = 400;
        e.code = "INVALID_RETURN_ITEM";
        throw e;
      }
      if (!Number.isFinite(it.qty) || it.qty <= 0) {
        const e = new Error(`Item devolución inválido: qty=${it.qty}`);
        e.httpStatus = 400;
        e.code = "INVALID_RETURN_ITEM";
        throw e;
      }
      if (!Number.isFinite(it.unit_price) || it.unit_price < 0) {
        const e = new Error(`Item devolución inválido: unit_price=${it.unit_price}`);
        e.httpStatus = 400;
        e.code = "INVALID_RETURN_ITEM";
        throw e;
      }
    }

    const totalReturn = calcReturnTotal(normalizedItems);

    const paidTotal = Number(sale.paid_total || 0);
    if (!(totalReturn > 0) || totalReturn - paidTotal > 0.00001) {
      const e = new Error("Monto de devolución inválido (supera lo pagado o es 0)");
      e.httpStatus = 400;
      e.code = "INVALID_RETURN_AMOUNT";
      throw e;
    }

    const paySum = payments.reduce((a, p) => a + toNum(p.amount), 0);
    if (Math.abs(paySum - totalReturn) > 0.01) {
      const e = new Error("Los pagos de devolución no coinciden con el monto a devolver");
      e.httpStatus = 400;
      e.code = "RETURN_PAYMENTS_MISMATCH";
      throw e;
    }

    const [insRet] = await sequelize.query(
      `
      INSERT INTO sale_returns
        (sale_id, amount, restock, reason, note, created_by, created_at)
      VALUES
        (:sale_id, :amount, :restock, :reason, :note, :created_by, NOW())
      `,
      {
        transaction: t,
        replacements: {
          sale_id: saleId,
          amount: totalReturn,
          restock: restock ? 1 : 0,
          reason,
          note,
          created_by: userId || null,
        },
      }
    );

    const returnId = toInt(insRet?.insertId, 0);
    if (!returnId) {
      const e = new Error("No se pudo crear sale_returns (insertId vacío)");
      e.httpStatus = 500;
      e.code = "RETURN_INSERT_FAILED";
      throw e;
    }

    for (const it of normalizedItems) {
      await sequelize.query(
        `
        INSERT INTO sale_return_items
          (return_id, product_id, warehouse_id, qty, unit_price, line_total, created_at)
        VALUES
          (:return_id, :product_id, :warehouse_id, :qty, :unit_price, :line_total, NOW())
        `,
        {
          transaction: t,
          replacements: {
            return_id: returnId,
            product_id: it.product_id,
            warehouse_id: it.warehouse_id,
            qty: it.qty,
            unit_price: it.unit_price,
            line_total: it.qty * it.unit_price,
          },
        }
      );

      if (restock) {
        const mv = await StockMovement.create(
          {
            type: "in",
            warehouse_id: it.warehouse_id,
            ref_type: "sale_return",
            ref_id: String(returnId),
            note: `Devolución de venta #${saleId}`,
            created_by: userId,
          },
          { transaction: t }
        );

        const p = await Product.findByPk(it.product_id, { transaction: t });
        await StockMovementItem.create(
          {
            movement_id: mv.id,
            product_id: it.product_id,
            qty: it.qty,
            unit_cost: p?.cost ?? null,
          },
          { transaction: t }
        );

        const sb = await StockBalance.findOne({
          where: { warehouse_id: it.warehouse_id, product_id: it.product_id },
          transaction: t,
          lock: t.LOCK.UPDATE,
        });

        if (sb) {
          await sb.update({ qty: literal(`qty + ${it.qty}`) }, { transaction: t });
        } else {
          await StockBalance.create(
            { warehouse_id: it.warehouse_id, product_id: it.product_id, qty: it.qty },
            { transaction: t }
          );
        }
      }
    }

    for (const p of payments) {
      const referenceIncoming = p.reference || null;
      const { dbMethod, providerCode } = mapPayMethodDetailed(p.method, referenceIncoming);
      const amount = toNum(p.amount);
      if (!Number.isFinite(amount) || amount <= 0) {
        const e = new Error(`Pago devolución inválido: amount=${p.amount}`);
        e.httpStatus = 400;
        e.code = "INVALID_RETURN_PAYMENT";
        throw e;
      }

      const installments = clampInstallments(p.installments ?? p.cuotas ?? 1, 1);

      const meta =
        installments > 1 || providerCode
          ? {
              provider_code: providerCode || null,
              installments,
              price_basis: "LIST",
              list_total: toNum(p.total_list ?? p.totalList ?? p.list_total ?? 0, 0) || null,
              per_installment_list: toNum(p.per_installment_list ?? p.perInstallmentList ?? 0, 0) || null,
            }
          : null;

      const notePay = meta ? mergePaymentNote(p.note || null, meta) : p.note ? String(p.note).slice(0, 255) : null;

      await sequelize.query(
        `
        INSERT INTO sale_return_payments
          (return_id, method, amount, reference, note, created_at)
        VALUES
          (:return_id, :method, :amount, :reference, :note, NOW())
        `,
        {
          transaction: t,
          replacements: {
            return_id: returnId,
            method: dbMethod,
            amount,
            reference: referenceIncoming ? String(referenceIncoming).slice(0, 120) : null,
            note: notePay ? String(notePay).slice(0, 255) : null,
          },
        }
      );
    }

    if (Math.abs(totalReturn - paidTotal) <= 0.01) {
      await sale.update({ status: "REFUNDED" }, { transaction: t });
    }

    await t.commit();

    return res.json({
      ok: true,
      data: {
        return_id: returnId,
        sale_id: saleId,
        amount: totalReturn,
        restock: restock ? 1 : 0,
        status_after: Math.abs(totalReturn - paidTotal) <= 0.01 ? "REFUNDED" : sale.status,
      },
      message: "Devolución registrada",
    });
  } catch (e) {
    if (t) await t.rollback();
    const status = e.httpStatus || 500;
    const code = e.code || "POS_RETURN_ERROR";
    logPos(req, "error", "createSaleReturn error", { code, err: e.message });
    return res.status(status).json({ ok: false, code, message: e.message });
  }
}

async function createSaleExchange(req, res) {
  req._rid = req._rid || rid(req);

  let t;
  try {
    await assertReturnsTablesExist();
    await assertExchangesTableExist();

    if (!req.user?.id) {
      return res.status(401).json({ ok: false, code: "UNAUTHORIZED", message: "No autenticado" });
    }

    const admin = isAdminReq(req);
    if (admin) logPos(req, "info", "createSaleExchange admin allowed");

    const userId = toInt(req.user.id, 0);
    const userBranchId = toInt(req.user.branch_id, 0);

    const body = req.body || {};
    const saleId = toInt(body.sale_id || body.id || req.params?.id, 0);
    if (!saleId) return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "sale_id requerido" });

    const returnPayload = body.return || body.returnData || {};
    const newSalePayload = body.new_sale || body.newSale || body.newSaleData || {};
    const exchangeNote = body.note ? String(body.note).slice(0, 255) : null;

    if (!Array.isArray(returnPayload.items) || !returnPayload.items.length) {
      return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "return.items requerido" });
    }
    if (!Array.isArray(returnPayload.payments) || !returnPayload.payments.length) {
      return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "return.payments requerido" });
    }
    if (!Array.isArray(newSalePayload.items) || !newSalePayload.items.length) {
      return res.status(400).json({ ok: false, code: "BAD_REQUEST", message: "new_sale.items requerido" });
    }

    t = await sequelize.transaction();

    const sale = await Sale.findByPk(saleId, {
      include: [{ model: SaleItem }, { model: Payment }],
      transaction: t,
      lock: t.LOCK.UPDATE,
    });

    if (!sale) {
      await t.rollback();
      return res.status(404).json({ ok: false, code: "SALE_NOT_FOUND", message: "Venta no encontrada" });
    }

    if (!admin) {
      if (!userBranchId) {
        await t.rollback();
        return res
          .status(400)
          .json({ ok: false, code: "BRANCH_REQUIRED", message: "El usuario no tiene sucursal asignada" });
      }
      if (toInt(sale.branch_id, 0) !== userBranchId) {
        await t.rollback();
        return res.status(403).json({
          ok: false,
          code: "CROSS_BRANCH_SALE",
          message: "No podés operar una venta de otra sucursal",
        });
      }
    }

    const restock = parseBool(returnPayload.restock, true);
    const reason = returnPayload.reason ? String(returnPayload.reason).slice(0, 255) : null;
    const note = returnPayload.note ? String(returnPayload.note).slice(0, 255) : null;

    const normalizedItems = returnPayload.items.map((it) => ({
      product_id: toInt(it.product_id, 0),
      warehouse_id: toInt(it.warehouse_id, 0),
      qty: toNum(it.qty),
      unit_price: toNum(it.unit_price),
    }));

    for (const it of normalizedItems) {
      if (!it.product_id || !it.warehouse_id) {
        const e = new Error("Item devolución inválido: product_id y warehouse_id requeridos");
        e.httpStatus = 400;
        e.code = "INVALID_RETURN_ITEM";
        throw e;
      }
      if (!Number.isFinite(it.qty) || it.qty <= 0) {
        const e = new Error(`Item devolución inválido: qty=${it.qty}`);
        e.httpStatus = 400;
        e.code = "INVALID_RETURN_ITEM";
        throw e;
      }
      if (!Number.isFinite(it.unit_price) || it.unit_price < 0) {
        const e = new Error(`Item devolución inválido: unit_price=${it.unit_price}`);
        e.httpStatus = 400;
        e.code = "INVALID_RETURN_ITEM";
        throw e;
      }
    }

    const totalReturn = calcReturnTotal(normalizedItems);
    const paidTotal = Number(sale.paid_total || 0);

    if (!(totalReturn > 0) || totalReturn - paidTotal > 0.00001) {
      const e = new Error("Monto de devolución inválido (supera lo pagado o es 0)");
      e.httpStatus = 400;
      e.code = "INVALID_RETURN_AMOUNT";
      throw e;
    }

    const paySum = (returnPayload.payments || []).reduce((a, p) => a + toNum(p.amount), 0);
    if (Math.abs(paySum - totalReturn) > 0.01) {
      const e = new Error("Los pagos de devolución no coinciden con el monto a devolver");
      e.httpStatus = 400;
      e.code = "RETURN_PAYMENTS_MISMATCH";
      throw e;
    }

    const [insRet] = await sequelize.query(
      `
      INSERT INTO sale_returns
        (sale_id, amount, restock, reason, note, created_by, created_at)
      VALUES
        (:sale_id, :amount, :restock, :reason, :note, :created_by, NOW())
      `,
      {
        transaction: t,
        replacements: {
          sale_id: saleId,
          amount: totalReturn,
          restock: restock ? 1 : 0,
          reason,
          note,
          created_by: userId || null,
        },
      }
    );

    const returnId = toInt(insRet?.insertId, 0);
    if (!returnId) {
      const e = new Error("No se pudo crear sale_returns (insertId vacío)");
      e.httpStatus = 500;
      e.code = "RETURN_INSERT_FAILED";
      throw e;
    }

    for (const it of normalizedItems) {
      await sequelize.query(
        `
        INSERT INTO sale_return_items
          (return_id, product_id, warehouse_id, qty, unit_price, line_total, created_at)
        VALUES
          (:return_id, :product_id, :warehouse_id, :qty, :unit_price, :line_total, NOW())
        `,
        {
          transaction: t,
          replacements: {
            return_id: returnId,
            product_id: it.product_id,
            warehouse_id: it.warehouse_id,
            qty: it.qty,
            unit_price: it.unit_price,
            line_total: it.qty * it.unit_price,
          },
        }
      );

      if (restock) {
        const mv = await StockMovement.create(
          {
            type: "in",
            warehouse_id: it.warehouse_id,
            ref_type: "sale_return",
            ref_id: String(returnId),
            note: `Devolución (cambio) de venta #${saleId}`,
            created_by: userId,
          },
          { transaction: t }
        );

        const p = await Product.findByPk(it.product_id, { transaction: t });
        await StockMovementItem.create(
          {
            movement_id: mv.id,
            product_id: it.product_id,
            qty: it.qty,
            unit_cost: p?.cost ?? null,
          },
          { transaction: t }
        );

        const sb = await StockBalance.findOne({
          where: { warehouse_id: it.warehouse_id, product_id: it.product_id },
          transaction: t,
          lock: t.LOCK.UPDATE,
        });

        if (sb) {
          await sb.update({ qty: literal(`qty + ${it.qty}`) }, { transaction: t });
        } else {
          await StockBalance.create(
            { warehouse_id: it.warehouse_id, product_id: it.product_id, qty: it.qty },
            { transaction: t }
          );
        }
      }
    }

    for (const p of returnPayload.payments || []) {
      const referenceIncoming = p.reference || null;
      const { dbMethod, providerCode } = mapPayMethodDetailed(p.method, referenceIncoming);
      const amount = toNum(p.amount);
      if (!Number.isFinite(amount) || amount <= 0) {
        const e = new Error(`Pago devolución inválido: amount=${p.amount}`);
        e.httpStatus = 400;
        e.code = "INVALID_RETURN_PAYMENT";
        throw e;
      }

      const installments = clampInstallments(p.installments ?? p.cuotas ?? 1, 1);
      const meta =
        installments > 1 || providerCode
          ? {
              provider_code: providerCode || null,
              installments,
              price_basis: "LIST",
              list_total: toNum(p.total_list ?? p.totalList ?? 0, 0) || null,
              per_installment_list: toNum(p.per_installment_list ?? p.perInstallmentList ?? 0, 0) || null,
            }
          : null;

      const notePay = meta ? mergePaymentNote(p.note || null, meta) : p.note ? String(p.note).slice(0, 255) : null;

      await sequelize.query(
        `
        INSERT INTO sale_return_payments
          (return_id, method, amount, reference, note, created_at)
        VALUES
          (:return_id, :method, :amount, :reference, :note, NOW())
        `,
        {
          transaction: t,
          replacements: {
            return_id: returnId,
            method: dbMethod,
            amount,
            reference: referenceIncoming ? String(referenceIncoming).slice(0, 120) : null,
            note: notePay ? String(notePay).slice(0, 255) : null,
          },
        }
      );
    }

    if (Math.abs(totalReturn - paidTotal) <= 0.01) {
      await sale.update({ status: "REFUNDED" }, { transaction: t });
    }

    const items2 = Array.isArray(newSalePayload.items) ? newSalePayload.items : [];
    const pays2 = Array.isArray(newSalePayload.payments) ? newSalePayload.payments : [];

    const extra2 = newSalePayload.extra && typeof newSalePayload.extra === "object" ? newSalePayload.extra : {};
    const c2 = extra2.customer && typeof extra2.customer === "object" ? extra2.customer : newSalePayload.customer || {};

    const first2 = String(c2.first_name || "").trim();
    const last2 = String(c2.last_name || "").trim();
    const fullName2 = String(`${first2} ${last2}`.trim());

    const customer_name2 =
      String(newSalePayload.customer_name || "").trim() ||
      fullName2 ||
      String(c2.name || "").trim() ||
      "Consumidor Final";

    const customer_phone2 =
      String(newSalePayload.customer_phone || "").trim() ||
      String(c2.phone || "").trim() ||
      String(c2.whatsapp || "").trim() ||
      null;

    const customer_doc2 =
      String(newSalePayload.customer_doc || "").trim() ||
      String(c2.doc || "").trim() ||
      String(c2.dni || "").trim() ||
      String(c2.cuit || "").trim() ||
      null;

    const note2 = newSalePayload.note || null;

    const normalizedItems2 = items2.map((i) => ({
      product_id: toNum(i.product_id),
      quantity: toNum(i.quantity),
      unit_price: toNum(i.unit_price),
    }));

    for (const it of normalizedItems2) {
      if (!it.product_id) {
        const e = new Error("Item inválido (cambio): falta product_id");
        e.httpStatus = 400;
        e.code = "INVALID_ITEM";
        throw e;
      }
      if (!Number.isFinite(it.quantity) || it.quantity <= 0) {
        const e = new Error(`Item inválido (cambio): quantity=${it.quantity}`);
        e.httpStatus = 400;
        e.code = "INVALID_ITEM";
        throw e;
      }
      if (!Number.isFinite(it.unit_price) || it.unit_price <= 0) {
        const e = new Error(`Item inválido (cambio): unit_price=${it.unit_price}`);
        e.httpStatus = 400;
        e.code = "INVALID_ITEM";
        throw e;
      }
    }

    const { warehouseId: ctxWh2 } = resolvePosContext(req);
    let resolvedWarehouseId2 = toInt(ctxWh2, 0);
    if (!resolvedWarehouseId2) resolvedWarehouseId2 = await resolveWarehouseForBranch(userBranchId);
    if (!resolvedWarehouseId2) {
      const e = new Error("Falta warehouse_id para nueva venta (cambio).");
      e.httpStatus = 400;
      e.code = "WAREHOUSE_REQUIRED";
      throw e;
    }

    let subtotal2 = 0;
    for (const it of normalizedItems2) subtotal2 += it.quantity * it.unit_price;

    const currentCashRegister2 = await getCurrentOpenCashRegister({
      branch_id: userBranchId,
      transaction: t,
    });

    const newSale = await Sale.create(
      {
        branch_id: userBranchId,
        cash_register_id: currentCashRegister2?.id || null,
        user_id: userId,
        status: "PAID",
        sale_number: null,

        customer_name: customer_name2,
        customer_phone: customer_phone2,
        customer_doc: customer_doc2,

        subtotal: subtotal2,
        discount_total: 0,
        tax_total: 0,
        total: subtotal2,
        paid_total: 0,
        change_total: 0,
        note: note2,
        sold_at: new Date(),
      },
      { transaction: t }
    );

    const mvOut = await StockMovement.create(
      {
        type: "out",
        warehouse_id: resolvedWarehouseId2,
        ref_type: "sale_exchange",
        ref_id: String(newSale.id),
        note: `Cambio: venta nueva #${newSale.id} (orig #${saleId})`,
        created_by: userId,
      },
      { transaction: t }
    );

    for (const it of normalizedItems2) {
      const p = await Product.findByPk(it.product_id, { transaction: t });
      if (!p) {
        const e = new Error(`Producto no existe (cambio): id=${it.product_id}`);
        e.httpStatus = 400;
        e.code = "PRODUCT_NOT_FOUND";
        throw e;
      }

      const sb = await StockBalance.findOne({
        where: { warehouse_id: resolvedWarehouseId2, product_id: it.product_id },
        transaction: t,
        lock: t.LOCK.UPDATE,
      });

      if (!sb) {
        const e = new Error(
          `No existe stock_balance (cambio) para producto ${p.sku || p.id} en depósito ${resolvedWarehouseId2}`
        );
        e.httpStatus = 409;
        e.code = "STOCK_BALANCE_MISSING";
        throw e;
      }

      if (Number(sb.qty) < it.quantity) {
        const e = new Error(`Stock insuficiente (cambio) para producto ${p.sku || p.id}`);
        e.httpStatus = 409;
        e.code = "STOCK_INSUFFICIENT";
        throw e;
      }

      await sb.update({ qty: literal(`qty - ${it.quantity}`) }, { transaction: t });

      const lineTotal = it.quantity * it.unit_price;

      await SaleItem.create(
        {
          sale_id: newSale.id,
          product_id: it.product_id,
          warehouse_id: resolvedWarehouseId2,
          quantity: it.quantity,
          unit_price: it.unit_price,
          discount_amount: 0,
          tax_amount: 0,
          line_total: lineTotal,
          product_name_snapshot: p.name,
          product_sku_snapshot: p.sku,
          product_barcode_snapshot: p.barcode,
        },
        { transaction: t }
      );

      await StockMovementItem.create(
        {
          movement_id: mvOut.id,
          product_id: it.product_id,
          qty: it.quantity,
          unit_cost: p.cost || null,
        },
        { transaction: t }
      );
    }

    let totalPaid2 = 0;
    for (const pay of pays2) {
      const amount = toNum(pay.amount);
      const referenceIncoming = pay.reference || pay.proof || null;
      const { dbMethod, providerCode } = mapPayMethodDetailed(pay.method, referenceIncoming);

      if (!Number.isFinite(amount) || amount <= 0) {
        const e = new Error(`Pago inválido (cambio): amount=${pay.amount}`);
        e.httpStatus = 400;
        e.code = "INVALID_PAYMENT";
        throw e;
      }

      const cardKind = String(pay.card_kind || pay.cardKind || pay.card_type || pay.cardType || "")
        .trim()
        .toUpperCase();
      const isDebit =
        providerCode === "debit" ||
        cardKind === "DEBIT" ||
        cardKind === "DEBITO" ||
        cardKind === "DÉBITO" ||
        pay.is_debit === true ||
        pay.isDebit === true;

      let installments = 1;
      if (dbMethod === "CREDIT_SJT" || providerCode === "credit_sjt") {
        installments = clampInstallments(pay.installments ?? pay.cuotas ?? 1, 1);
      } else if (dbMethod === "CARD" && !isDebit) {
        installments = clampInstallments(pay.installments ?? pay.cuotas ?? 1, 1);
      } else {
        installments = 1;
      }

      const meta =
        installments > 1 || providerCode
          ? {
              provider_code: providerCode || null,
              installments,
              price_basis:
                (dbMethod === "CARD" && installments > 1 && !isDebit) || dbMethod === "CREDIT_SJT" ? "LIST" : null,
              list_total: toNum(pay.total_list ?? pay.totalList ?? 0, 0) || null,
              per_installment_list: toNum(pay.per_installment_list ?? pay.perInstallmentList ?? 0, 0) || null,
              card_kind: dbMethod === "CARD" ? (isDebit ? "DEBIT" : "CREDIT") : "CREDIT",
            }
          : null;

      totalPaid2 += amount;

      let ref = referenceIncoming || null;
      if (!ref && dbMethod === "CREDIT_SJT") ref = "SJCREDIT";
      if (!ref && dbMethod === "MERCADOPAGO") ref = "MERCADOPAGO";

      const notePay = meta ? mergePaymentNote(pay.note || null, meta) : pay.note || null;

      await Payment.create(
        {
          sale_id: newSale.id,
          method: dbMethod,
          amount,
          installments,
          reference: ref,
          note: notePay,
          paid_at: new Date(),
        },
        { transaction: t }
      );
    }

    if (!pays2.length) totalPaid2 = subtotal2;

    newSale.paid_total = totalPaid2;
    newSale.change_total = totalPaid2 - subtotal2;
    await newSale.save({ transaction: t });

    const diff = Number(newSale.total || 0) - Number(totalReturn || 0);

    await sequelize.query(
      `
      INSERT INTO sale_exchanges
        (original_sale_id, return_id, new_sale_id, original_total, returned_amount, new_total, diff, note, created_by, created_at)
      VALUES
        (:orig_sale, :return_id, :new_sale, :orig_total, :returned_amount, :new_total, :diff, :note, :created_by, NOW())
      `,
      {
        transaction: t,
        replacements: {
          orig_sale: saleId,
          return_id: returnId,
          new_sale: newSale.id,
          orig_total: Number(sale.total || 0),
          returned_amount: Number(totalReturn || 0),
          new_total: Number(newSale.total || 0),
          diff,
          note: exchangeNote,
          created_by: userId || null,
        },
      }
    );

    await t.commit();

    return res.json({
      ok: true,
      message: "Cambio registrado",
      data: {
        original_sale_id: saleId,
        return_id: returnId,
        new_sale_id: newSale.id,
        returned_amount: totalReturn,
        new_total: Number(newSale.total || 0),
        diff,
      },
    });
  } catch (e) {
    if (t) await t.rollback();
    const status = e.httpStatus || 500;
    const code = e.code || "POS_EXCHANGE_ERROR";
    logPos(req, "error", "createSaleExchange error", { code, err: e.message });
    return res.status(status).json({ ok: false, code, message: e.message });
  }
}

module.exports = {
  getContext,
  listProductsForPos,
  createSale,
  createSaleReturn,
  createSaleExchange,
};